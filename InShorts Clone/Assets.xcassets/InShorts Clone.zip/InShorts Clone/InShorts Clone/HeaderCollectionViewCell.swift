//
//  HeaderCollectionViewCell.swift
//  InShorts Clone
//
//  Created by Sunitha Balasubramanian on 01/09/20.
//  Copyright © 2020 Sunitha Balasubramanian. All rights reserved.
//

import UIKit

class HeaderCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var HeaderImageView: UIImageView!
}
